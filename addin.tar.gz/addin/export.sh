#!/bin/bash
ikvmc -target:library -keyfile:proskor.snk -version:0.9.1.0 -out:epsilon.dll antlr.jar commons.jar epsilon.jar
#ikvmc -target:library -keyfile:proskor.snk -version:3.7.2.0 -out:swt.dll swt.jar
#ikvmc -target:library -keyfile:proskor.snk -version:1.1.0.0 -out:hamcrest.dll hamcrest.jar
#ikvmc -target:library -keyfile:proskor.snk -version:4.8.2.0 -out:junit.dll junit.jar hamcrest.jar
#ikvmc -target:library -keyfile:proskor.snk -version:2.9.2.0 -out:scala.dll scala-library.jar
#ikvmc -target:library -keyfile:proskor.snk -version:1.0.0.0 -r:Interop.EA.dll -out:addin.dll addin.jar
